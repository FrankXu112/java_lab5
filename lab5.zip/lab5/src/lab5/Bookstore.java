package lab5;

import java.util.ArrayList;
import java.util.Collections;

public class Bookstore {
	private ArrayList<Book> booklist;
	
	public Bookstore() {
		booklist =  new ArrayList<Book>();
	}
	
	public void addBook(Name firstname, Name lastname, String title, int yearpublished) {
		try {
			booklist.add(new Book(firstname, lastname, title, yearpublished));
		} catch (InvalidBookDateException | InvalidArgumentException e) {
			// TODO Auto-generated catch block
			System.err.println(e);
			System.out.println();
		}
	}
	
	public void addBiography(Name firstname, Name lastname, String title, int yearpublished, Name subject) {
		try {
			booklist.add(new Biography(firstname, lastname, title, yearpublished, subject));
		} catch (InvalidBookDateException | InvalidArgumentException e) {
			// TODO Auto-generated catch block
			System.err.println(e);
			System.out.println();
		}
	}
	
	public void displayBooks() {
		System.out.println("before sorting:");
		for(Book books: booklist) {
			System.out.println(books);
		}
		Collections.sort(booklist);
		System.out.println();
		System.out.println("after sorting: ");
		for(Book books: booklist) {
			System.out.println(books);
		}
	}
	
	public static void main(String[] args) {
		Bookstore bookstore =  new Bookstore();
		bookstore.addBook(new Name("Frank"), new Name("Xu"), "Fly", 2016);
		bookstore.addBook(new Name("Hellen"), new Name("Snow"), "Deep Down", 2017);
		bookstore.addBook(new Name("Sam"), new Name("Tali"), "Cook Book", 2015);
		bookstore.addBiography(new Name("John"), new Name("Snow"), "Winterfell", 2013, new Name("bio"));
		bookstore.displayBooks();
	}

}
