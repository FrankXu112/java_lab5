package lab5;

@SuppressWarnings("serial")
public class InvalidBookDateException extends Exception {

	public InvalidBookDateException(String message) {
		super(message);
	}
}
