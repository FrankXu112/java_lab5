package lab5;

public class Book implements Comparable<Book>{
	
	private Name firstName;
	private Name lastName;
	private String title;
	private int yearPublished;
	
	/**
	 * @param firstName set first name
	 * @param lastName set last name
	 * @param title set title
	 * @param yearPublished set year published
	 * @throws InvalidBookDateException throw Invalid Book Date Exception
	 * @throws InvalidArgumentException throw Invalid Argument Exception
	 */
	public Book(Name firstName, Name lastName, String title, int yearPublished) throws InvalidBookDateException, InvalidArgumentException {
		setFirstName(firstName);
		setLastName(lastName);
		setTitle(title);
		setYearPublished(yearPublished);
	}

	/**
	 * @return the firstName
	 */
	public final Name getFirstName() {
		return firstName;
	}

	/**
	 * set first name with exception
	 * @param firstName the firstName to set
	 * @throws InvalidArgumentException throw Invalid Argument Exception
	 */
	public final void setFirstName(Name firstName) throws InvalidArgumentException {
		if(firstName != null && firstName.getName() != "") {
			this.firstName = firstName;
		}
		else
			throw new InvalidArgumentException("first name cannot be empty");
	}

	/**
	 * @return the lastName
	 */
	public final Name getLastName() {
		return lastName;
	}

	/**
	 * set last name with exception
	 * @param lastName the lastName to set
	 * @throws InvalidArgumentException throw Invalid Argument Exception
	 */
	public final void setLastName(Name lastName) throws InvalidArgumentException {
		if(lastName != null && lastName.getName() != "") {
			this.lastName = lastName;
		}
		else
			throw new InvalidArgumentException("last name cannot be empty");
	}

	/**
	 * @return the title
	 */
	public final String getTitle() {
		return title;
	}

	/**
	 * set title with exception
	 * @param title the title to set
	 * @throws InvalidArgumentException throw Invalid Argument Exception
	 */
	public final void setTitle(String title) throws InvalidArgumentException {
		if(title != null && title != "") {
			this.title = title;
		}
		else
			throw new InvalidArgumentException("title cannot be empty");
	}

	/**
	 * @return the yearPublished
	 */
	public final int getYearPublished() {
		return yearPublished;
	}
	
	/**
	 * set publish year with exception
	 * @param yearPublished the yearPublished to set
	 * @throws InvalidBookDateException  throw invalid book date exception
	 */
	public final void setYearPublished(int yearPublished) throws InvalidBookDateException {
		if(yearPublished <= 2017) {
			this.yearPublished = yearPublished;
		}
		else
			throw new InvalidBookDateException("publish year cannot be larger than 2017");
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((firstName == null) ? 0 : firstName.hashCode());
		result = prime * result + ((lastName == null) ? 0 : lastName.hashCode());
		result = prime * result + ((title == null) ? 0 : title.hashCode());
		result = prime * result + yearPublished;
		return result;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Book other = (Book) obj;
		if (title == null) {
			if (other.title != null)
				return false;
		} else if (!title.equals(other.title))
			return false;
		if (yearPublished != other.yearPublished)
			return false;
		return true;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "book title: " + this.getTitle() + ", publish year: " + this.getYearPublished() + ", author: " + this.getFirstName() + " " + this.getLastName();
	}

	@Override
	public int compareTo(Book bk) {
		return (bk.getYearPublished() - this.getYearPublished());
	}
	
	
}
